from django.contrib import admin

from reply.models import Reply

# Register your models here.
admin.site.register(Reply)